#!/usr/bin/env node
// Manual cleanup script - run with: node scripts/cleanup.js

const fs = require('fs');
const path = require('path');

const TEMP_DIR = process.env.TEMP_DIR || '/tmp/yt-clipper';
const TTL_MINUTES = parseInt(process.env.FILE_TTL_MINUTES || '30');

function getDirSize(dir) {
  if (!fs.existsSync(dir)) return 0;
  let total = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) total += getDirSize(full);
    else total += fs.statSync(full).size;
  }
  return total;
}

function formatBytes(b) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / (1024 * 1024)).toFixed(1)} MB`;
}

if (!fs.existsSync(TEMP_DIR)) {
  console.log('No temp directory found, nothing to clean.');
  process.exit(0);
}

const now = Date.now();
const TTL_MS = TTL_MINUTES * 60 * 1000;
const jobs = fs.readdirSync(TEMP_DIR, { withFileTypes: true }).filter(e => e.isDirectory());

let deleted = 0;
let kept = 0;
let totalFreed = 0;

for (const job of jobs) {
  const jobPath = path.join(TEMP_DIR, job.name);
  const mtime = fs.statSync(jobPath).mtimeMs;
  const age = now - mtime;

  if (age > TTL_MS) {
    const size = getDirSize(jobPath);
    fs.rmSync(jobPath, { recursive: true, force: true });
    totalFreed += size;
    deleted++;
    console.log(`🗑  Deleted ${job.name} (age: ${Math.round(age / 60000)}m, size: ${formatBytes(size)})`);
  } else {
    kept++;
    console.log(`⏳ Kept    ${job.name} (age: ${Math.round(age / 60000)}m, remaining: ${Math.round((TTL_MS - age) / 60000)}m)`);
  }
}

console.log(`\n✅ Cleanup done: deleted ${deleted}, kept ${kept}, freed ${formatBytes(totalFreed)}`);
