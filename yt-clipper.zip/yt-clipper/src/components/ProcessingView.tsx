'use client';

import { useEffect, useState, useRef } from 'react';
import type { ProcessingJob, ClipFile } from '@/types';
import { formatDuration, formatBytes } from '@/lib/clientUtils';

interface Props {
  jobId: string;
  onReset: () => void;
}

const STATUS_LABELS: Record<string, string> = {
  queued: 'In queue...',
  fetching_info: 'Loading video info...',
  downloading: 'Downloading from YouTube...',
  processing: 'Processing video...',
  splitting: 'Splitting into clips...',
  done: 'All clips ready!',
  error: 'Something went wrong',
};

const STATUS_COLORS: Record<string, string> = {
  queued: 'text-warn',
  fetching_info: 'text-accent-bright',
  downloading: 'text-accent-bright',
  processing: 'text-accent-bright',
  splitting: 'text-neon',
  done: 'text-neon',
  error: 'text-danger',
};

export default function ProcessingView({ jobId, onReset }: Props) {
  const [job, setJob] = useState<ProcessingJob | null>(null);
  const [error, setError] = useState('');
  const [selectedClip, setSelectedClip] = useState<ClipFile | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    async function poll() {
      try {
        const res = await fetch(`/api/status/${jobId}`);
        const json = await res.json();
        if (!json.success) {
          setError(json.error || 'Failed to get job status');
          return;
        }
        setJob(json.data.job);
        if (json.data.job.status === 'done' || json.data.job.status === 'error') {
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      } catch {
        setError('Network error while polling job status.');
      }
    }

    poll();
    intervalRef.current = setInterval(poll, 2000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [jobId]);

  const isDone = job?.status === 'done';
  const isError = job?.status === 'error';
  const progress = job?.progress ?? 0;

  return (
    <main className="relative min-h-screen">
      {/* Background */}
      <div className="fixed inset-0 bg-void" />
      <div className="fixed inset-0 bg-hero-glow pointer-events-none" />
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(rgba(108,71,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(108,71,255,0.03) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-10 animate-fade-up">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center cursor-pointer hover:opacity-70 transition"
              style={{ background: 'linear-gradient(135deg, #6c47ff, #00f5c4)' }}
              onClick={onReset}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M15 18l-6-6 6-6" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <span className="font-display font-semibold text-white/60 text-sm uppercase tracking-wide">
              YT Clipper
            </span>
          </div>
          <button
            onClick={onReset}
            className="btn-secondary text-sm px-4 py-2"
          >
            + New Video
          </button>
        </div>

        {/* Video info card */}
        {job?.videoInfo && (
          <div className="card border border-border rounded-2xl overflow-hidden mb-8 animate-fade-up">
            <div className="flex flex-col sm:flex-row gap-0">
              <div className="relative sm:w-48 sm:h-32 h-40 flex-shrink-0 overflow-hidden">
                <img
                  src={job.videoInfo.thumbnail}
                  alt={job.videoInfo.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-panel hidden sm:block" />
                {job.videoInfo.isShort && (
                  <div className="absolute top-2 left-2 bg-accent text-white text-xs font-mono px-2 py-0.5 rounded-full">
                    Shorts
                  </div>
                )}
              </div>
              <div className="p-5 flex-1 min-w-0">
                <h2 className="font-display font-bold text-white text-base sm:text-lg leading-tight mb-2 line-clamp-2">
                  {job.videoInfo.title}
                </h2>
                <div className="flex flex-wrap gap-3 text-muted text-xs font-mono">
                  <span>⏱ {formatDuration(job.videoInfo.duration)}</span>
                  <span>👤 {job.videoInfo.uploader}</span>
                  {job.videoInfo.viewCount && (
                    <span>👁 {job.videoInfo.viewCount.toLocaleString()} views</span>
                  )}
                  <span>🎬 {job.options.quality}</span>
                  <span>✂️ {job.options.clipDuration}s clips</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Progress section */}
        {!isDone && !isError && (
          <div className="card border border-border rounded-2xl p-6 mb-8 animate-fade-up">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-accent animate-pulse-slow" />
                <span className={`font-display font-semibold text-sm ${STATUS_COLORS[job?.status ?? 'queued']}`}>
                  {STATUS_LABELS[job?.status ?? 'queued']}
                </span>
              </div>
              <span className="font-mono text-sm text-white/60">{progress}%</span>
            </div>

            {/* Progress bar */}
            <div className="relative h-2 bg-ghost rounded-full overflow-hidden mb-3">
              <div
                className="absolute inset-y-0 left-0 rounded-full transition-all duration-500"
                style={{
                  width: `${progress}%`,
                  background: 'linear-gradient(90deg, #6c47ff, #00f5c4)',
                  boxShadow: '0 0 10px rgba(108,71,255,0.5)',
                }}
              />
              {/* Shimmer overlay */}
              <div
                className="absolute inset-0 shimmer-bg"
                style={{ opacity: progress < 100 ? 1 : 0 }}
              />
            </div>

            <p className="text-muted text-xs font-mono">
              {job?.statusMessage || 'Initializing...'}
            </p>
          </div>
        )}

        {/* Error state */}
        {isError && (
          <div className="card border border-danger/30 rounded-2xl p-6 mb-8 animate-scale-in">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-danger/15 flex items-center justify-center flex-shrink-0">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" stroke="#ff3b5c" strokeWidth="2"/>
                  <line x1="12" y1="8" x2="12" y2="12" stroke="#ff3b5c" strokeWidth="2" strokeLinecap="round"/>
                  <circle cx="12" cy="16" r="1" fill="#ff3b5c"/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-display font-bold text-danger mb-1">Processing Failed</h3>
                <p className="text-white/60 text-sm leading-relaxed">{job?.error}</p>
              </div>
            </div>
            <button onClick={onReset} className="btn-primary mt-5 w-full text-sm py-3">
              Try Again
            </button>
          </div>
        )}

        {/* Done + Clips */}
        {isDone && job?.clips && (
          <div className="animate-fade-up">
            {/* Summary */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="font-display font-bold text-2xl text-white mb-1">
                  {job.clips.length} Clips Ready
                </h2>
                <p className="text-muted text-sm font-mono">
                  Total size: {formatBytes(job.clips.reduce((a, c) => a + c.size, 0))}
                </p>
              </div>
              <a
                href="#"
                className="btn-secondary text-sm px-4 py-2 flex items-center gap-2 opacity-50 cursor-not-allowed"
                title="Download all as ZIP coming soon"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <polyline points="7 10 12 15 17 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <line x1="12" y1="15" x2="12" y2="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                Download All (ZIP)
              </a>
            </div>

            {/* Video preview modal */}
            {selectedClip && (
              <div
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-void/90 backdrop-blur"
                onClick={(e) => { if (e.target === e.currentTarget) setSelectedClip(null); }}
              >
                <div className="card border-glow-active rounded-2xl overflow-hidden w-full max-w-2xl animate-scale-in">
                  <div className="flex items-center justify-between p-4 border-b border-border">
                    <div>
                      <span className="font-display font-bold text-white">Clip {selectedClip.index}</span>
                      <span className="text-muted text-sm font-mono ml-3">
                        {formatDuration(selectedClip.startTime)} → {formatDuration(selectedClip.endTime)}
                      </span>
                    </div>
                    <button
                      onClick={() => setSelectedClip(null)}
                      className="w-8 h-8 rounded-lg bg-ghost flex items-center justify-center hover:bg-border transition text-muted hover:text-white"
                    >
                      ✕
                    </button>
                  </div>
                  <video
                    ref={videoRef}
                    src={selectedClip.downloadUrl}
                    controls
                    autoPlay
                    className="w-full aspect-video bg-black"
                  />
                  <div className="p-4 flex justify-end">
                    <a
                      href={selectedClip.downloadUrl}
                      download
                      className="btn-primary text-sm px-5 py-2 flex items-center gap-2"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                        <polyline points="7 10 12 15 17 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <line x1="12" y1="15" x2="12" y2="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      </svg>
                      Download Clip
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Clips grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {job.clips.map((clip, i) => (
                <div
                  key={clip.index}
                  className="card border border-border hover:border-accent/40 rounded-xl overflow-hidden
                    transition-all duration-200 group cursor-pointer animate-fade-up"
                  style={{ animationDelay: `${Math.min(i * 50, 400)}ms` }}
                >
                  {/* Clip header */}
                  <div
                    className="relative aspect-video bg-ghost flex items-center justify-center overflow-hidden"
                    onClick={() => setSelectedClip(clip)}
                  >
                    {/* Gradient bg */}
                    <div
                      className="absolute inset-0"
                      style={{
                        background: `linear-gradient(135deg, rgba(108,71,255,0.15) 0%, rgba(0,0,0,0.5) 100%)`,
                      }}
                    />
                    {/* Play button */}
                    <div className="relative z-10 w-12 h-12 rounded-full bg-accent/80 backdrop-blur flex items-center justify-center
                      group-hover:bg-accent group-hover:scale-110 transition-all duration-200 shadow-accent">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                        <polygon points="5 3 19 12 5 21 5 3"/>
                      </svg>
                    </div>
                    {/* Time badge */}
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs font-mono px-2 py-0.5 rounded">
                      {formatDuration(clip.duration)}
                    </div>
                    {/* Clip number */}
                    <div className="absolute top-2 left-2 bg-accent/80 text-white text-xs font-mono px-2 py-0.5 rounded">
                      #{clip.index}
                    </div>
                  </div>

                  {/* Clip info */}
                  <div className="p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-display font-semibold text-white text-sm">
                        Clip {clip.index}
                      </span>
                      <span className="text-muted text-xs font-mono">
                        {formatBytes(clip.size)}
                      </span>
                    </div>
                    <div className="text-muted text-xs font-mono mb-3">
                      {formatDuration(clip.startTime)} — {formatDuration(clip.endTime)}
                    </div>
                    <a
                      href={clip.downloadUrl}
                      download
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center justify-center gap-2 w-full py-2 px-3 rounded-lg
                        bg-accent/10 border border-accent/20 text-accent-bright text-xs font-display font-semibold
                        hover:bg-accent/20 hover:border-accent/40 transition-all duration-150"
                    >
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                        <polyline points="7 10 12 15 17 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <line x1="12" y1="15" x2="12" y2="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      </svg>
                      Download
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer note */}
            <p className="text-muted text-xs text-center mt-8 font-mono">
              ⚠️ Clips will be automatically deleted in 30 minutes. Download what you need now.
            </p>
          </div>
        )}
      </div>
    </main>
  );
}
