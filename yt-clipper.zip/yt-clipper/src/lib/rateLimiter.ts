import { RateLimiterMemory } from 'rate-limiter-flexible';
import PQueue from 'p-queue';
import { NextRequest } from 'next/server';

const RPM = parseInt(process.env.RATE_LIMIT_RPM || '10');
const MAX_JOBS = parseInt(process.env.MAX_CONCURRENT_JOBS || '3');

export const rateLimiter = new RateLimiterMemory({
  points: RPM,
  duration: 60,
  blockDuration: 60,
});

export const processingQueue = new PQueue({ concurrency: MAX_JOBS });

export function getClientIp(req: NextRequest): string {
  return (
    req.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
    req.headers.get('x-real-ip') ||
    'unknown'
  );
}

export async function checkRateLimit(ip: string): Promise<{ allowed: boolean; retryAfter?: number }> {
  try {
    await rateLimiter.consume(ip);
    return { allowed: true };
  } catch (res: unknown) {
    const retryAfter = Math.ceil((res as { msBeforeNext: number }).msBeforeNext / 1000);
    return { allowed: false, retryAfter };
  }
}
