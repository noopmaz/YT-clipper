import fs from 'fs';
import path from 'path';
import { logger } from './logger';

const TEMP_DIR = process.env.TEMP_DIR || '/tmp/yt-clipper';
const TTL_MS = parseInt(process.env.FILE_TTL_MINUTES || '30') * 60 * 1000;
const MAX_STORAGE = parseInt(process.env.MAX_STORAGE_BYTES || '524288000'); // 500MB

let cleanupInterval: NodeJS.Timeout | null = null;

export function getTempDir(jobId: string): string {
  const dir = path.join(TEMP_DIR, jobId);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function deleteJobFiles(jobId: string): void {
  const dir = path.join(TEMP_DIR, jobId);
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
    logger.info('Deleted job files', { jobId });
  }
}

export function getClipPath(jobId: string, filename: string): string | null {
  const filePath = path.join(TEMP_DIR, jobId, 'clips', filename);
  if (fs.existsSync(filePath)) return filePath;
  return null;
}

function getDirSize(dir: string): number {
  if (!fs.existsSync(dir)) return 0;
  let total = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) total += getDirSize(full);
    else total += fs.statSync(full).size;
  }
  return total;
}

export function runCleanup(): void {
  if (!fs.existsSync(TEMP_DIR)) return;

  const now = Date.now();
  const jobs = fs.readdirSync(TEMP_DIR, { withFileTypes: true })
    .filter(e => e.isDirectory())
    .map(e => ({
      name: e.name,
      path: path.join(TEMP_DIR, e.name),
      mtime: fs.statSync(path.join(TEMP_DIR, e.name)).mtimeMs,
    }));

  let deleted = 0;
  for (const job of jobs) {
    if (now - job.mtime > TTL_MS) {
      fs.rmSync(job.path, { recursive: true, force: true });
      deleted++;
      logger.debug('Auto-deleted expired job folder', { jobId: job.name });
    }
  }

  // Enforce max storage
  const totalSize = getDirSize(TEMP_DIR);
  if (totalSize > MAX_STORAGE) {
    // Delete oldest first
    const sorted = jobs.sort((a, b) => a.mtime - b.mtime);
    for (const job of sorted) {
      if (getDirSize(TEMP_DIR) <= MAX_STORAGE * 0.8) break;
      fs.rmSync(job.path, { recursive: true, force: true });
      deleted++;
      logger.warn('Deleted job to free storage', { jobId: job.name });
    }
  }

  if (deleted > 0) logger.info(`Cleanup: removed ${deleted} job folder(s)`);
}

export function startCleanupScheduler(): void {
  if (cleanupInterval) return;
  // Run every 5 minutes
  cleanupInterval = setInterval(runCleanup, 5 * 60 * 1000);
  // Also run on startup
  runCleanup();
  logger.info('Cleanup scheduler started', { ttlMinutes: TTL_MS / 60000 });
}
