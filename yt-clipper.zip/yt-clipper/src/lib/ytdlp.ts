import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs';
import { VideoInfo, VideoQuality, ProcessOptions } from '@/types';
import { logger } from './logger';

const execAsync = promisify(exec);

const YTDLP = process.env.YTDLP_PATH || 'yt-dlp';
const MAX_DURATION = parseInt(process.env.MAX_VIDEO_DURATION || '1800');

function buildYtdlpArgs(extra: string[] = []): string[] {
  const args: string[] = [];
  if (process.env.YTDLP_COOKIES_PATH) {
    args.push('--cookies', process.env.YTDLP_COOKIES_PATH);
  }
  if (process.env.YTDLP_PROXY) {
    args.push('--proxy', process.env.YTDLP_PROXY);
  }
  args.push('--no-playlist', '--no-warnings');
  return [...args, ...extra];
}

export function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

export function isValidYouTubeUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    const validHosts = ['youtube.com', 'www.youtube.com', 'youtu.be', 'm.youtube.com'];
    return validHosts.includes(parsed.hostname) && !!extractVideoId(url);
  } catch {
    return false;
  }
}

export async function fetchVideoInfo(url: string): Promise<VideoInfo> {
  const args = buildYtdlpArgs([
    '--dump-json',
    '--no-download',
    url,
  ]);

  logger.info('Fetching video info', { url });

  const { stdout } = await execAsync(`${YTDLP} ${args.map(a => `"${a}"`).join(' ')}`, {
    timeout: 30_000,
    maxBuffer: 10 * 1024 * 1024,
  });

  const data = JSON.parse(stdout.trim());

  if (data.duration > MAX_DURATION) {
    throw new Error(
      `Video duration (${Math.round(data.duration / 60)} min) exceeds the maximum allowed (${Math.round(MAX_DURATION / 60)} min).`
    );
  }

  // Parse available qualities from formats
  const qualities = new Set<VideoQuality>(['best', '360p']);
  if (data.formats) {
    for (const fmt of data.formats) {
      if (fmt.height >= 1080) qualities.add('1080p');
      else if (fmt.height >= 720) qualities.add('720p');
      else if (fmt.height >= 480) qualities.add('480p');
    }
    qualities.add('audio_only');
  }

  const isShort = (data.duration || 0) <= 60 ||
    (data.webpage_url || '').includes('/shorts/') ||
    (data.original_url || '').includes('/shorts/');

  return {
    id: data.id,
    title: data.title,
    description: data.description?.slice(0, 500),
    duration: data.duration || 0,
    thumbnail: data.thumbnail || `https://img.youtube.com/vi/${data.id}/maxresdefault.jpg`,
    uploader: data.uploader || data.channel || 'Unknown',
    viewCount: data.view_count,
    uploadDate: data.upload_date,
    availableQualities: Array.from(qualities) as VideoQuality[],
    isShort,
  };
}

function qualityToFormat(quality: VideoQuality): string {
  switch (quality) {
    case 'best':
      return 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best';
    case '1080p':
      return 'bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best[height<=1080]';
    case '720p':
      return 'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best[height<=720]';
    case '480p':
      return 'bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/best[height<=480][ext=mp4]/best[height<=480]';
    case '360p':
      return 'bestvideo[height<=360][ext=mp4]+bestaudio[ext=m4a]/best[height<=360][ext=mp4]/best[height<=360]';
    case 'audio_only':
      return 'bestaudio[ext=m4a]/bestaudio';
    default:
      return 'best[ext=mp4]/best';
  }
}

export async function downloadVideo(
  options: ProcessOptions,
  outputDir: string,
  onProgress?: (pct: number, msg: string) => void
): Promise<string> {
  const { youtubeUrl, quality } = options;

  fs.mkdirSync(outputDir, { recursive: true });
  const outputPath = path.join(outputDir, 'source.%(ext)s');
  const format = qualityToFormat(quality);

  const args = buildYtdlpArgs([
    '-f', format,
    '--merge-output-format', 'mp4',
    '--no-part',
    '--progress',
    '-o', outputPath,
    youtubeUrl,
  ]);

  logger.info('Downloading video', { url: youtubeUrl, quality, format });

  return new Promise((resolve, reject) => {
    const proc = spawn(YTDLP, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let finalPath = '';
    let stderr = '';

    proc.stdout.on('data', (data: Buffer) => {
      const line = data.toString();
      // Parse yt-dlp progress: [download]  45.3% of ~123.4MiB at 2.3MiB/s
      const m = line.match(/\[download\]\s+([\d.]+)%/);
      if (m && onProgress) {
        const pct = Math.min(95, parseFloat(m[1]));
        onProgress(pct, `Downloading... ${m[1]}%`);
      }
      // Capture final filename
      const dest = line.match(/Destination:\s+(.+\.mp4)/);
      if (dest) finalPath = dest[1].trim();
      const merge = line.match(/Merging formats into "(.+\.mp4)"/);
      if (merge) finalPath = merge[1].trim();
    });

    proc.stderr.on('data', (d: Buffer) => { stderr += d.toString(); });

    proc.on('close', (code) => {
      if (code !== 0) {
        logger.error('yt-dlp failed', { code, stderr });
        return reject(new Error(`Download failed. ${stderr.slice(-300)}`));
      }

      // Fallback: find the mp4 file in outputDir
      if (!finalPath || !fs.existsSync(finalPath)) {
        const files = fs.readdirSync(outputDir).filter(f => f.startsWith('source'));
        if (files.length === 0) return reject(new Error('Downloaded file not found'));
        finalPath = path.join(outputDir, files[0]);
      }

      logger.info('Download complete', { path: finalPath });
      resolve(finalPath);
    });

    proc.on('error', (err) => {
      reject(new Error(`yt-dlp not found. Please install yt-dlp. Details: ${err.message}`));
    });
  });
}
