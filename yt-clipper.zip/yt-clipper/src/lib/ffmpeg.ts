import ffmpeg from 'fluent-ffmpeg';
import path from 'path';
import fs from 'fs';
import { ClipFile, ClipDuration } from '@/types';
import { logger } from './logger';

if (process.env.FFMPEG_PATH) {
  ffmpeg.setFfmpegPath(process.env.FFMPEG_PATH);
}
if (process.env.FFPROBE_PATH) {
  ffmpeg.setFfprobePath(process.env.FFPROBE_PATH);
}

export async function getVideoDuration(filePath: string): Promise<number> {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, meta) => {
      if (err) return reject(err);
      resolve(meta.format.duration || 0);
    });
  });
}

export async function generateThumbnail(
  filePath: string,
  outputDir: string,
  timestamp: number
): Promise<string | null> {
  const thumbFile = `thumb_${Math.floor(timestamp)}.jpg`;
  const thumbPath = path.join(outputDir, thumbFile);

  return new Promise((resolve) => {
    ffmpeg(filePath)
      .seekInput(timestamp)
      .outputOptions(['-vframes 1', '-q:v 3'])
      .output(thumbPath)
      .on('end', () => resolve(thumbPath))
      .on('error', () => resolve(null))
      .run();
  });
}

export async function splitVideo(
  inputPath: string,
  outputDir: string,
  clipDuration: ClipDuration,
  jobId: string,
  onProgress?: (index: number, total: number, pct: number, msg: string) => void
): Promise<ClipFile[]> {
  const duration = await getVideoDuration(inputPath);
  const total = Math.ceil(duration / clipDuration);
  const clips: ClipFile[] = [];
  const clipsDir = path.join(outputDir, 'clips');
  fs.mkdirSync(clipsDir, { recursive: true });

  logger.info('Splitting video', { duration, clipDuration, totalClips: total, jobId });

  for (let i = 0; i < total; i++) {
    const startTime = i * clipDuration;
    const actualDuration = Math.min(clipDuration, duration - startTime);
    if (actualDuration < 1) break;

    const filename = `clip_${String(i + 1).padStart(3, '0')}.mp4`;
    const outputPath = path.join(clipsDir, filename);

    await splitSegment(inputPath, outputPath, startTime, actualDuration);

    const stat = fs.statSync(outputPath);

    clips.push({
      index: i + 1,
      filename,
      startTime,
      endTime: startTime + actualDuration,
      duration: actualDuration,
      size: stat.size,
      downloadUrl: `/api/clips/${jobId}/${filename}`,
    });

    const pct = Math.round(((i + 1) / total) * 100);
    onProgress?.(i + 1, total, pct, `Splitting clip ${i + 1} of ${total}...`);
    logger.debug(`Clip ${i + 1}/${total} done`, { filename, startTime, actualDuration });
  }

  return clips;
}

function splitSegment(
  inputPath: string,
  outputPath: string,
  startTime: number,
  duration: number
): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .seekInput(startTime)
      .duration(duration)
      .outputOptions([
        '-c:v libx264',
        '-c:a aac',
        '-preset fast',
        '-crf 23',
        '-movflags +faststart',
        '-avoid_negative_ts make_zero',
      ])
      .output(outputPath)
      .on('end', () => resolve())
      .on('error', (err) => reject(new Error(`FFmpeg error: ${err.message}`)))
      .run();
  });
}

export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
