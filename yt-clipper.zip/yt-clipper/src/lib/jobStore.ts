import NodeCache from 'node-cache';
import { ProcessingJob, JobStatus } from '@/types';
import { logger } from './logger';

// Jobs stored in memory with TTL (seconds)
const JOB_TTL = (parseInt(process.env.FILE_TTL_MINUTES || '30') + 5) * 60;

const cache = new NodeCache({
  stdTTL: JOB_TTL,
  checkperiod: 120,
  useClones: false,
});

cache.on('expired', (key: string, job: ProcessingJob) => {
  logger.info(`Job ${key} expired from cache`, { jobId: key });
  // Cleanup is handled by the file cleanup scheduler
});

export const jobStore = {
  create(job: ProcessingJob): void {
    cache.set(job.jobId, job);
  },

  get(jobId: string): ProcessingJob | null {
    return cache.get<ProcessingJob>(jobId) ?? null;
  },

  update(jobId: string, updates: Partial<ProcessingJob>): ProcessingJob | null {
    const job = cache.get<ProcessingJob>(jobId);
    if (!job) return null;
    const updated = { ...job, ...updates, updatedAt: Date.now() };
    cache.set(jobId, updated);
    return updated;
  },

  updateStatus(
    jobId: string,
    status: JobStatus,
    progress: number,
    message: string
  ): ProcessingJob | null {
    return jobStore.update(jobId, { status, progress, statusMessage: message });
  },

  setError(jobId: string, error: string): ProcessingJob | null {
    return jobStore.update(jobId, {
      status: 'error',
      error,
      statusMessage: error,
      progress: 0,
    });
  },

  delete(jobId: string): boolean {
    return cache.del(jobId) > 0;
  },

  all(): ProcessingJob[] {
    const keys = cache.keys();
    return keys
      .map((k) => cache.get<ProcessingJob>(k))
      .filter((j): j is ProcessingJob => !!j);
  },
};
