// ============================================
// Core Types for YT-Clipper
// ============================================

export type JobStatus =
  | 'queued'
  | 'fetching_info'
  | 'downloading'
  | 'processing'
  | 'splitting'
  | 'done'
  | 'error';

export type VideoQuality = 'best' | '1080p' | '720p' | '480p' | '360p' | 'audio_only';
export type ClipDuration = 15 | 30 | 60;

export interface VideoInfo {
  id: string;
  title: string;
  description?: string;
  duration: number; // seconds
  thumbnail: string;
  uploader: string;
  viewCount?: number;
  uploadDate?: string;
  availableQualities: VideoQuality[];
  isShort: boolean;
}

export interface ClipFile {
  index: number;
  filename: string;
  startTime: number; // seconds
  endTime: number;   // seconds
  duration: number;  // seconds
  size: number;      // bytes
  downloadUrl: string;
  thumbnailUrl?: string;
}

export interface ProcessingJob {
  jobId: string;
  status: JobStatus;
  progress: number;     // 0–100
  statusMessage: string;
  videoInfo?: VideoInfo;
  clips?: ClipFile[];
  error?: string;
  createdAt: number;    // timestamp
  updatedAt: number;
  options: ProcessOptions;
}

export interface ProcessOptions {
  youtubeUrl: string;
  quality: VideoQuality;
  clipDuration: ClipDuration;
  startTime?: number;
  endTime?: number;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  code?: string;
}

export interface StartJobResponse {
  jobId: string;
}

export interface JobStatusResponse {
  job: ProcessingJob;
}

export interface ClipsResponse {
  clips: ClipFile[];
  totalDuration: number;
  totalSize: number;
}
