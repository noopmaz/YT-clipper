import type { Metadata } from 'next';
import { Syne, DM_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  weight: ['400', '500', '600', '700', '800'],
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  weight: ['300', '400', '500', '600'],
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  weight: ['400', '500'],
});

export const metadata: Metadata = {
  title: 'YT Clipper — Cut YouTube Videos into Clips',
  description: 'Paste any YouTube link and get it split into perfectly timed clips instantly. Powered by yt-dlp and FFmpeg.',
  keywords: ['youtube clipper', 'video splitter', 'yt-dlp', 'ffmpeg', 'clip maker'],
  openGraph: {
    title: 'YT Clipper',
    description: 'Split YouTube videos into clips in seconds',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${syne.variable} ${dmSans.variable} ${jetbrains.variable}`}>
      <body className="bg-void text-white font-body antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
