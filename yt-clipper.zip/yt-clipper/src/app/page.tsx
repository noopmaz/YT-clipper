'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import ProcessingView from '@/components/ProcessingView';
import type { ClipDuration, VideoQuality } from '@/types';

type Step = 'home' | 'processing' | 'done';

export default function HomePage() {
  const [step, setStep] = useState<Step>('home');
  const [url, setUrl] = useState('');
  const [quality, setQuality] = useState<VideoQuality>('720p');
  const [clipDuration, setClipDuration] = useState<ClipDuration>(30);
  const [jobId, setJobId] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit() {
    if (!url.trim()) return setError('Please enter a YouTube URL.');
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url.trim(), quality, clipDuration }),
      });
      const json = await res.json();

      if (!json.success) {
        setError(json.error || 'Failed to start processing.');
        setLoading(false);
        return;
      }

      setJobId(json.data.jobId);
      setStep('processing');
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function handlePaste(e: React.ClipboardEvent<HTMLInputElement>) {
    setTimeout(() => {
      const val = e.currentTarget.value;
      if (val.includes('youtube.com') || val.includes('youtu.be')) {
        setError('');
      }
    }, 10);
  }

  if (step === 'processing' || step === 'done') {
    return (
      <ProcessingView
        jobId={jobId}
        onReset={() => {
          setStep('home');
          setUrl('');
          setJobId('');
        }}
      />
    );
  }

  return (
    <main className="relative min-h-screen overflow-hidden">
      {/* Background effects */}
      <div className="fixed inset-0 bg-void" />
      <div className="fixed inset-0 bg-hero-glow pointer-events-none" />
      <div
        className="fixed inset-0 opacity-100 pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(rgba(108,71,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(108,71,255,0.04) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
      />

      {/* Floating orbs */}
      <div
        className="fixed w-96 h-96 rounded-full pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(108,71,255,0.15) 0%, transparent 70%)',
          top: '-5rem',
          right: '10%',
          animation: 'glowPulse 4s ease-in-out infinite',
        }}
      />
      <div
        className="fixed w-64 h-64 rounded-full pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(0,245,196,0.08) 0%, transparent 70%)',
          bottom: '20%',
          left: '5%',
          animation: 'glowPulse 5s ease-in-out infinite 1s',
        }}
      />

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 py-16">
        {/* Logo / Header */}
        <div className="animate-fade-up mb-4">
          <div className="flex items-center gap-3 mb-6">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #6c47ff, #00f5c4)' }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
                <polyline points="14 2 14 8 20 8" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <line x1="16" y1="13" x2="8" y2="13" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
                <line x1="16" y1="17" x2="8" y2="17" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
                <line x1="10" y1="9" x2="8" y2="9" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <span className="font-display text-lg font-700 text-white/60 tracking-wide uppercase text-sm">
              YT Clipper
            </span>
          </div>
        </div>

        {/* Hero text */}
        <div className="animate-fade-up delay-100 text-center max-w-3xl mb-12">
          <h1 className="font-display font-extrabold text-5xl sm:text-6xl md:text-7xl leading-none mb-6">
            <span className="text-gradient">Cut any YouTube</span>
            <br />
            <span className="text-white">video into clips.</span>
          </h1>
          <p className="text-muted text-lg sm:text-xl max-w-xl mx-auto leading-relaxed">
            Paste a YouTube URL. Choose quality and clip length.
            Get perfectly split MP4 files — instantly.
          </p>
        </div>

        {/* Main card */}
        <div className="animate-fade-up delay-200 w-full max-w-2xl">
          <div className="card border-glow p-1 rounded-2xl">
            <div className="bg-panel rounded-xl p-6 sm:p-8">
              {/* URL input */}
              <div className="mb-6">
                <label className="block font-display text-sm font-semibold text-white/60 uppercase tracking-wider mb-3">
                  YouTube URL
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z" fill="#ff0000" opacity="0.7"/>
                      <polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="white"/>
                    </svg>
                  </div>
                  <input
                    type="url"
                    value={url}
                    onChange={(e) => { setUrl(e.target.value); setError(''); }}
                    onPaste={handlePaste}
                    onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
                    placeholder="https://www.youtube.com/watch?v=..."
                    className="w-full bg-ghost border border-border focus:border-accent/60 focus:ring-2 focus:ring-accent/20
                      rounded-xl pl-12 pr-4 py-4 text-white placeholder-muted font-mono text-sm
                      outline-none transition-all duration-200"
                  />
                </div>
                {error && (
                  <div className="mt-3 flex items-center gap-2 text-danger text-sm animate-scale-in">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                      <circle cx="12" cy="12" r="10"/>
                      <line x1="12" y1="8" x2="12" y2="12" stroke="white" strokeWidth="2"/>
                      <line x1="12" y1="16" x2="12.01" y2="16" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    {error}
                  </div>
                )}
              </div>

              {/* Options grid */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                {/* Quality selector */}
                <div>
                  <label className="block font-display text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
                    Quality
                  </label>
                  <div className="flex flex-col gap-1">
                    {(['best', '1080p', '720p', '480p', '360p'] as VideoQuality[]).map((q) => (
                      <button
                        key={q}
                        onClick={() => setQuality(q)}
                        className={`text-left px-3 py-2 rounded-lg text-sm font-mono transition-all duration-150 ${
                          quality === q
                            ? 'bg-accent text-white shadow-accent'
                            : 'text-muted hover:text-white hover:bg-ghost'
                        }`}
                      >
                        {q === 'best' ? '⭐ Best' : q}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Duration selector */}
                <div>
                  <label className="block font-display text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
                    Clip Length
                  </label>
                  <div className="flex flex-col gap-1">
                    {([15, 30, 60] as ClipDuration[]).map((d) => (
                      <button
                        key={d}
                        onClick={() => setClipDuration(d)}
                        className={`text-left px-3 py-2 rounded-lg text-sm font-mono transition-all duration-150 ${
                          clipDuration === d
                            ? 'bg-neon/20 text-neon border border-neon/30'
                            : 'text-muted hover:text-white hover:bg-ghost'
                        }`}
                      >
                        {d}s — {d === 15 ? 'Shorts' : d === 30 ? 'Reels' : '1 Minute'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Submit button */}
              <button
                onClick={handleSubmit}
                disabled={loading || !url.trim()}
                className="w-full btn-primary flex items-center justify-center gap-3 py-4 text-base
                  disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Starting...
                  </>
                ) : (
                  <>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <polygon points="5 3 19 12 5 21 5 3" fill="currentColor"/>
                    </svg>
                    Start Clipping
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Features row */}
        <div className="animate-fade-up delay-300 grid grid-cols-2 sm:grid-cols-4 gap-3 mt-12 max-w-2xl w-full">
          {[
            { icon: '⚡', label: 'FFmpeg Powered', desc: 'Lossless splitting' },
            { icon: '📦', label: 'yt-dlp Backend', desc: 'Any YouTube video' },
            { icon: '🎬', label: 'Multiple Qualities', desc: '360p to 1080p' },
            { icon: '🗑️', label: 'Auto Cleanup', desc: 'Files deleted in 30m' },
          ].map((f) => (
            <div key={f.label} className="glass-light border border-border rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">{f.icon}</div>
              <div className="font-display text-xs font-semibold text-white/70 mb-1">{f.label}</div>
              <div className="text-muted text-xs">{f.desc}</div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <p className="animate-fade-up delay-400 mt-12 text-muted text-xs text-center">
          Max video length: 30 minutes · Files auto-deleted after 30 minutes · No account required
        </p>
      </div>
    </main>
  );
}
