import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { getClipPath } from '@/lib/cleanup';
import { jobStore } from '@/lib/jobStore';

export async function GET(
  _req: NextRequest,
  { params }: { params: { jobId: string; filename: string } }
) {
  const { jobId, filename } = params;

  // Validate params (prevent path traversal)
  if (!/^[0-9a-f-]{36}$/.test(jobId)) {
    return NextResponse.json({ error: 'Invalid job ID' }, { status: 400 });
  }
  if (!/^clip_\d{3}\.mp4$/.test(filename)) {
    return NextResponse.json({ error: 'Invalid filename' }, { status: 400 });
  }

  const job = jobStore.get(jobId);
  if (!job || job.status !== 'done') {
    return NextResponse.json({ error: 'Job not found or not complete' }, { status: 404 });
  }

  const filePath = getClipPath(jobId, filename);
  if (!filePath) {
    return NextResponse.json({ error: 'Clip file not found' }, { status: 404 });
  }

  const stat = fs.statSync(filePath);
  const clipIndex = filename.match(/clip_(\d+)\.mp4/)?.[1] || '1';

  const fileStream = fs.createReadStream(filePath);
  // @ts-expect-error — ReadableStream from node fs
  const webStream = new ReadableStream({
    start(controller) {
      fileStream.on('data', (chunk) => controller.enqueue(chunk));
      fileStream.on('end', () => controller.close());
      fileStream.on('error', (err) => controller.error(err));
    },
    cancel() {
      fileStream.destroy();
    },
  });

  return new NextResponse(webStream, {
    headers: {
      'Content-Type': 'video/mp4',
      'Content-Length': String(stat.size),
      'Content-Disposition': `attachment; filename="clip_${clipIndex}_${jobId.slice(0, 8)}.mp4"`,
      'Cache-Control': 'private, max-age=1800',
    },
  });
}
