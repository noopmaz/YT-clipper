import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { jobStore } from '@/lib/jobStore';
import { processingQueue, checkRateLimit, getClientIp } from '@/lib/rateLimiter';
import { isValidYouTubeUrl, fetchVideoInfo, downloadVideo } from '@/lib/ytdlp';
import { splitVideo } from '@/lib/ffmpeg';
import { getTempDir, startCleanupScheduler } from '@/lib/cleanup';
import { logger } from '@/lib/logger';
import type { ProcessOptions, ClipDuration, VideoQuality } from '@/types';

// Start cleanup scheduler on first request
startCleanupScheduler();

const schema = z.object({
  url: z.string().url(),
  quality: z.enum(['best', '1080p', '720p', '480p', '360p', 'audio_only']).default('720p'),
  clipDuration: z.union([z.literal(15), z.literal(30), z.literal(60)]).default(30),
});

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const rateResult = await checkRateLimit(ip);

  if (!rateResult.allowed) {
    return NextResponse.json(
      { success: false, error: `Rate limit exceeded. Try again in ${rateResult.retryAfter}s.`, code: 'RATE_LIMIT' },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ success: false, error: 'Invalid JSON body', code: 'BAD_REQUEST' }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: parsed.error.errors[0].message, code: 'VALIDATION' }, { status: 400 });
  }

  const { url, quality, clipDuration } = parsed.data;

  if (!isValidYouTubeUrl(url)) {
    return NextResponse.json({ success: false, error: 'Invalid YouTube URL. Please provide a valid YouTube video link.', code: 'INVALID_URL' }, { status: 400 });
  }

  const jobId = uuidv4();
  const options: ProcessOptions = { youtubeUrl: url, quality: quality as VideoQuality, clipDuration: clipDuration as ClipDuration };

  jobStore.create({
    jobId,
    status: 'queued',
    progress: 0,
    statusMessage: 'Job queued...',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    options,
  });

  logger.info('Job created', { jobId, ip, url, quality, clipDuration });

  // Run in background queue
  processingQueue.add(() => runJob(jobId, options));

  return NextResponse.json({ success: true, data: { jobId } }, { status: 202 });
}

async function runJob(jobId: string, options: ProcessOptions): Promise<void> {
  const outputDir = getTempDir(jobId);

  try {
    // Step 1: Fetch video info
    jobStore.updateStatus(jobId, 'fetching_info', 5, 'Fetching video information...');
    const videoInfo = await fetchVideoInfo(options.youtubeUrl);
    jobStore.update(jobId, { videoInfo, status: 'downloading', progress: 10, statusMessage: 'Starting download...' });

    // Step 2: Download
    jobStore.updateStatus(jobId, 'downloading', 10, 'Downloading video...');
    const videoPath = await downloadVideo(options, outputDir, (pct, msg) => {
      jobStore.updateStatus(jobId, 'downloading', Math.round(10 + pct * 0.55), msg);
    });

    // Step 3: Split
    jobStore.updateStatus(jobId, 'splitting', 65, 'Splitting into clips...');
    const clips = await splitVideo(videoPath, outputDir, options.clipDuration, jobId, (idx, total, pct, msg) => {
      jobStore.updateStatus(jobId, 'splitting', Math.round(65 + pct * 0.33), msg);
    });

    // Done
    jobStore.update(jobId, {
      status: 'done',
      progress: 100,
      statusMessage: `Done! ${clips.length} clips created.`,
      clips,
    });

    logger.info('Job complete', { jobId, clips: clips.length });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    logger.error('Job failed', { jobId, error: msg });
    jobStore.setError(jobId, msg);
  }
}
