import { NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

async function checkBinary(name: string, cmd: string): Promise<{ ok: boolean; version?: string }> {
  try {
    const { stdout } = await execAsync(cmd, { timeout: 5000 });
    return { ok: true, version: stdout.trim().split('\n')[0] };
  } catch {
    return { ok: false };
  }
}

export async function GET() {
  const [ffmpeg, ytdlp] = await Promise.all([
    checkBinary('ffmpeg', 'ffmpeg -version'),
    checkBinary('yt-dlp', 'yt-dlp --version'),
  ]);

  const allOk = ffmpeg.ok && ytdlp.ok;

  return NextResponse.json(
    {
      status: allOk ? 'ok' : 'degraded',
      timestamp: new Date().toISOString(),
      dependencies: { ffmpeg, ytdlp },
      env: {
        maxDuration: process.env.MAX_VIDEO_DURATION,
        ttlMinutes: process.env.FILE_TTL_MINUTES,
        maxConcurrentJobs: process.env.MAX_CONCURRENT_JOBS,
      },
    },
    { status: allOk ? 200 : 503 }
  );
}
