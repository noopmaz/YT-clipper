import { NextRequest, NextResponse } from 'next/server';
import { jobStore } from '@/lib/jobStore';

export async function GET(
  _req: NextRequest,
  { params }: { params: { jobId: string } }
) {
  const { jobId } = params;

  if (!jobId || !/^[0-9a-f-]{36}$/.test(jobId)) {
    return NextResponse.json({ success: false, error: 'Invalid job ID', code: 'BAD_REQUEST' }, { status: 400 });
  }

  const job = jobStore.get(jobId);

  if (!job) {
    return NextResponse.json({ success: false, error: 'Job not found or expired', code: 'NOT_FOUND' }, { status: 404 });
  }

  // Don't expose full file paths to client
  const safeJob = {
    ...job,
    clips: job.clips?.map(c => ({
      index: c.index,
      filename: c.filename,
      startTime: c.startTime,
      endTime: c.endTime,
      duration: c.duration,
      size: c.size,
      downloadUrl: c.downloadUrl,
    })),
  };

  return NextResponse.json({ success: true, data: { job: safeJob } });
}
